module.exports={
    'secret':'tr4v3g0'
}